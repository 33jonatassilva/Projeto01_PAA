#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definição da estrutura de aluno
struct Aluno {
    int semestre;
    char turma;
    char periodo;
    char nome[100];
    char disciplina[100];
    float mediaFinal;
};

// Função de comparação para ordenação por nome
int compareNome(const void *a, const void *b) {
    return strcmp(((struct Aluno *)a)->nome, ((struct Aluno *)b)->nome);
}

// Função de comparação para ordenação por semestre
int compareSemestre(const void *a, const void *b) {
    return ((struct Aluno *)a)->semestre - ((struct Aluno *)b)->semestre;
}

// Função de comparação para ordenação por semestre, turma, período, disciplina e nome
int compareTudo(const void *a, const void *b) {
    int result = ((struct Aluno *)a)->semestre - ((struct Aluno *)b)->semestre;
    if (result != 0) return result;

    result = ((struct Aluno *)a)->turma - ((struct Aluno *)b)->turma;
    if (result != 0) return result;

    result = ((struct Aluno *)a)->periodo - ((struct Aluno *)b)->periodo;
    if (result != 0) return result;

    result = strcmp(((struct Aluno *)a)->disciplina, ((struct Aluno *)b)->disciplina);
    if (result != 0) return result;

    return strcmp(((struct Aluno *)a)->nome, ((struct Aluno *)b)->nome);
}

// Função de comparação para ordenação por disciplina e média final (decrescente)
int compareDisciplinaMedia(const void *a, const void *b) {
    int result = strcmp(((struct Aluno *)a)->disciplina, ((struct Aluno *)b)->disciplina);
    if (result != 0) return result;

    return ((struct Aluno *)b)->mediaFinal - ((struct Aluno *)a)->mediaFinal;
}

// Função de comparação para ordenação por período, semestre, turma, disciplina e nome
int comparePeriodoSemestreTudo(const void *a, const void *b) {
    int result = ((struct Aluno *)a)->periodo - ((struct Aluno *)b)->periodo;
    if (result != 0) return result;

    result = ((struct Aluno *)a)->semestre - ((struct Aluno *)b)->semestre;
    if (result != 0) return result;

    result = ((struct Aluno *)a)->turma - ((struct Aluno *)b)->turma;
    if (result != 0) return result;

    result = strcmp(((struct Aluno *)a)->disciplina, ((struct Aluno *)b)->disciplina);
    if (result != 0) return result;

    return strcmp(((struct Aluno *)a)->nome, ((struct Aluno *)b)->nome);
}

int main() {
    FILE *entrada = fopen("Arquivo-projeto-teste.csv", "r");
    if (entrada == NULL) {
        printf("Erro ao abrir o arquivo de entrada.\n");
        return 1;
    }

    FILE *saida = fopen("saida.csv", "w");
    if (saida == NULL) {
        printf("Erro ao abrir o arquivo de saída.\n");
        fclose(entrada);
        return 1;
    }

    struct Aluno alunos[1000]; // Suponha um limite de 1000 alunos
    int numAlunos = 0;

    // Ler os dados do arquivo de entrada
    while (fscanf(entrada, "%d,%c,%c,%[^,],%[^,],%f\n", &alunos[numAlunos].semestre, &alunos[numAlunos].turma, &alunos[numAlunos].periodo, alunos[numAlunos].nome, alunos[numAlunos].disciplina, &alunos[numAlunos].mediaFinal) == 6) {
        numAlunos++;
    }

    int opcao;
    printf("Escolha uma opção:\n");
    printf("1. Ordenar por nome\n");
    printf("2. Ordenar por semestre\n");
    printf("3. Ordenar por semestre, turma, período, disciplina e nome\n");
    printf("4. Ordenar por disciplina e média final (decrescente)\n");
    printf("5. Ordenar por período, semestre, turma, disciplina e nome\n");
    scanf("%d", &opcao);

    switch (opcao) {
        case 1:
            qsort(alunos, numAlunos, sizeof(struct Aluno), compareNome);
            break;
        case 2:
            qsort(alunos, numAlunos, sizeof(struct Aluno), compareSemestre);
            break;
        case 3:
            qsort(alunos, numAlunos, sizeof(struct Aluno), compareTudo);
            break;
        case 4:
            qsort(alunos, numAlunos, sizeof(struct Aluno), compareDisciplinaMedia);
            break;
        case 5:
            qsort(alunos, numAlunos, sizeof(struct Aluno), comparePeriodoSemestreTudo);
            break;
        default:
            printf("Opção inválida.\n");
            fclose(entrada);
            fclose(saida);
            return 1;
    }

    // Escrever os dados ordenados no arquivo de saída
    for (int i = 0; i < numAlunos; i++) {
        fprintf(saida, "%d,%c,%c,%s,%s,%.2f\n", alunos[i].semestre, alunos[i].turma, alunos[i].periodo, alunos[i].nome, alunos[i].disciplina, alunos[i].mediaFinal);
    }

    printf("Dados ordenados com sucesso no arquivo de saída.\n");

    fclose(entrada);
    fclose(saida);

    return 0;
}
