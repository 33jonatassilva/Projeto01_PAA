#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#define TAM 100

// Struct pessoa é criada com 6 atributos, conforme descrito.

struct pessoa
{
    char semestre[2];
    char turma;
    char periodo;
    char nome[TAM];
    char disciplina[TAM];
    char media_final[3];
};


// Mudando o nome de struct pessoa para somente pessoa

typedef struct pessoa pessoa;

/*
  
  void merging(int low, int mid, int high) {
     int l1, l2, i;
  
     for(l1 = low, l2 = mid + 1, i = low; l1 <= mid && l2 <= high; i++) {
        if(pessoa[l1] <= a[l2])
           b[i] = a[l1++];
        else
           b[i] = a[l2++];
     }
     
     while(l1 <= mid)    
        b[i++] = a[l1++];
  
     while(l2 <= high)   
        b[i++] = a[l2++];
  
     for(i = low; i <= high; i++)
        a[i] = b[i];
  }
  
  void sort(int low, int high) {
     int mid;
     
     if(low < high) {
        mid = (low + high) / 2;
        sort(low, mid);
        sort(mid+1, high);
        merging(low, mid, high);
     } else { 
        return;
     }   
  }
*/

/*
    printf("1. Ordenar por nome\n"
           "2. Ordenar por semestre\n"
           "3. Ordenar por semestre, turma, período, disciplina e nome\n"
           "4. Ordenar por disciplina e média final (decrescente)\n"
           "5. Ordenar por período, semestre, turma, disciplina e nome\n\n"
           "Digite uma opção: ");
*/
int main() {

  // Vetor aluno é criado com quantidade de elementos igual à contante TAM.
  
  pessoa aluno[TAM]; 

  // Variável arquivo do tipo ponteiro é criada.
  
  FILE *arquivo;

  // Arquivo é aberto para leitura "r".
  
  arquivo = fopen("Arquivo-projeto-teste.csv", "r");

  // Vetor de caracteres de tamanho 100 é criado.
  
  char linha[100];

  // Variável ponteiro de char pt é criada.
  
  char *pt;

  // For de i até a quantidade máxima de linhas no arquivo menos 1, que neste caso são 39 linhas.
  
  for (int i = 0; i < 39; i++){

    // Variável pt recebe linha que o método fgets pega do arquivo
    
    pt = strtok(fgets(linha, 100, arquivo), ",");

    // For de 0 até o número de elementos em cada linha menos 1 que neste caso são 6.
    
    for (int j = 0; j < 6; j++) {

      // Switch estabelece 6 casos possíveis e atribui os valores aos atributos da struct pessoa.
      switch (j) {
        case 0:
          stpcpy(aluno[i].semestre, pt);
          pt = strtok(NULL, ",");
          break;
        case 1:
          aluno[i].turma = *pt;
          pt = strtok(NULL, ",");
          break;
        case 2:
          aluno[i].periodo = *pt;
          pt = strtok(NULL, ",");
          break;
        case 3:
          stpcpy(aluno[i].nome, pt);
          pt = strtok(NULL, ",");
          break;
        case 4:
          stpcpy(aluno[i].disciplina, pt);
          pt = strtok(NULL, ",");
          break;
        case 5:
          stpcpy(aluno[i].media_final, pt);
          pt = strtok(NULL, ",");
          break;
        default:
          break;
      }
    }

    
    printf("%s\n", aluno[i].semestre);
    printf("%c\n", aluno[i].turma);
    printf("%c\n", aluno[i].periodo);
    printf("%s\n", aluno[i].nome);
    printf("%s\n", aluno[i].disciplina);
    printf("%s\n", aluno[i].media_final);

    
    
    
    /*fscanf(arquivo, "%c", &turma);
      fscanf(arquivo, "%c", &periodo);
      aluno[i].semestre = semestre;
      aluno[i].turma = turma;
      printf("%d\n", aluno[i].semestre);
      printf("%c\n", aluno[i].turma);
      printf("%c\n", aluno[i].periodo);
      printf("%s\n", aluno[i].nome);
      printf("%f\n", aluno[i].media_final);*/
  }


  
  fclose(arquivo);
}



