#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#define TAM 40
#define TAM_SMALL 20



// Struct pessoa é criada com 6 atributos, conforme descrito.

struct aluno
{
    char semestre[2];
    char turma;
    char periodo;
    char nome[TAM];
    char disciplina[TAM_SMALL];
    char media_final[3];
};

// Mudando o nome de struct pessoa para somente pessoa

int contaLinhas(FILE *arquivo) {
  
  arquivo = fopen("Arquivo-projeto-teste-.csv", "r");
  
  int tam = 0;
  char caractere;
  while ((caractere = fgetc(arquivo)) != EOF) {
      if (caractere == '\n') {
          tam++;
      }
  }
  fclose(arquivo);
  return tam;
}
  
void merge(struct aluno aluno[], struct aluno esquerda[], int esquerda_tam, struct aluno direita[], int direita_tam, int opcao) {
    int i = 0, j = 0, k = 0; 

    while (i < esquerda_tam && j < direita_tam) {
        switch (opcao) {
          
        case 1:
            if (strcmp(esquerda[i].semestre, direita[j].semestre) <= 0) {
                aluno[k++] = esquerda[i++];
            } else {
                aluno[k++] = direita[j++];
            }
            break;
        case 2:
            if (esquerda[i].turma <= direita[j].turma) {
                aluno[k++] = esquerda[i++];
            } else {
                aluno[k++] = direita[j++];
            }
            break;

        case 3:
            if (esquerda[i].periodo <= direita[j].periodo) {
                aluno[k++] = esquerda[i++];
            } else {
                aluno[k++] = direita[j++];
            }
            break;
        case 4:
            if (strcmp(esquerda[i].nome, direita[j].nome) <= 0) {
                aluno[k++] = esquerda[i++];
            } else {
                aluno[k++] = direita[j++];
            }
            break;

        case 5:
            if (strcmp(esquerda[i].disciplina, direita[j].disciplina) <= 0) {
                aluno[k++] = esquerda[i++];
            } else {
                aluno[k++] = direita[j++];
            }
            break;

        case 6: 
            if (strcmp(esquerda[i].media_final, direita[j].media_final) <= 0) {
                aluno[k++] = esquerda[i++];
            } else {
                aluno[k++] = direita[j++];
            }
            break;
          
        case 7: // Se a opção 7 for selecionada no param. opcao do merge, compara as medias finais (decrescente)
            if (strcmp(esquerda[i].media_final, direita[j].media_final) > 0) {
                aluno[k++] = esquerda[i++];
            } else {
                aluno[k++] = direita[j++];
            }
            break;
        }
    }

    while (i < esquerda_tam) {
        aluno[k++] = esquerda[i++];
    }

    while (j < direita_tam) {
        aluno[k++] = direita[j++];
    }
}


void mergeSort(struct aluno *aluno, int size, int opcao) {
  
    if (size > 1) {
      
        int meio = size / 2;

        // Alocação dinâmica de memória para 'esquerda' e 'direita'
        struct aluno *esquerda = malloc(meio * sizeof(struct aluno));
        struct aluno *direita = malloc((size - meio) * sizeof(struct aluno));

      
        for (int i = 0; i < meio; i++) {
            esquerda[i] = aluno[i];
        }

      
        for (int i = meio; i < size; i++) {
            direita[i - meio] = aluno[i];
        }

        // Chamada recursiva para ordenar as duas metades
        mergeSort(esquerda, meio, opcao);
        mergeSort(direita, size - meio, opcao);

        // Mesclar as duas metades ordenadas
        merge(aluno, esquerda, meio, direita, size - meio, opcao);

        // Liberar a memória alocada
        free(esquerda);
        free(direita);
    }
}


int main(void) {

  // Vetor aluno é criado com quantidade de elementos igual à contante TAM.
  

  // Variável arquivo do tipo ponteiro é criada.
  
  FILE *arquivo;

  // Arquivo é aberto para leitura "r".
  
  arquivo = fopen("Arquivo-projeto-teste-.csv", "r");

  // Vetor de caracteres de tamanho 100 é criado.
  int size_struct_aluno = contaLinhas(arquivo);

  struct aluno aluno[size_struct_aluno]; 
  char linha[size_struct_aluno];

  // Variável ponteiro de char pt é criada.
  
  char *pt;

  // For de i até a quantidade máxima de linhas no arquivo menos 1, que neste caso são 39 linhas.
  
  for (int i = 0; i < size_struct_aluno; i++){

    // Variável pt recebe linha que o método fgets pega do arquivo
    
    pt = strtok(fgets(linha, 100, arquivo), ",");

    // For de 0 até o número de elementos em cada linha menos 1 que neste caso são 6.
    
    for (int j = 0; j < 6; j++) {

      // Switch estabelece 6 casos possíveis e atribui os valores aos atributos da struct pessoa.
      switch (j) {
        case 0:
          stpcpy(aluno[i].semestre, pt);
          pt = strtok(NULL, ",");
          break;
        case 1:
          aluno[i].turma = *pt;
          pt = strtok(NULL, ",");
          break;
        case 2:
          aluno[i].periodo = *pt;
          pt = strtok(NULL, ",");
          break;
        case 3:
          stpcpy(aluno[i].nome, pt);
          pt = strtok(NULL, ",");
          break;
        case 4:
          stpcpy(aluno[i].disciplina, pt);
          pt = strtok(NULL, ",");
          break;
        case 5:
          stpcpy(aluno[i].media_final, pt);
          pt = strtok(NULL, ",");
          break;
        default:
          break;
      }
    }
  }
  
  int opcao;
  
  do {
  printf("1. Ordenar por nome\n"
       "2. Ordenar por semestre\n"
       "3. Ordenar por semestre, turma, período, disciplina e nome\n"
       "4. Ordenar por disciplina e média final (decrescente)\n"
       "5. Ordenar por período, semestre, turma, disciplina e nome\n\n"
       "Digite uma opção: ");
  
  
  scanf("%d", &opcao);
  } while (opcao != 1 && opcao != 2 && opcao != 3 && opcao != 4 && opcao != 5);
  


  switch (opcao) {

    case 1:
      //1. Ordenar por nome
      mergeSort(aluno, 39, 4);
      break;

    case 2:
      //2. Ordenar por semestre
      mergeSort(aluno, 39, 1);
      break;

    case 3: 
      //3. Ordenar por semestre, turma, período, disciplina e nome\n
    
      mergeSort(aluno, 39, 5);
      mergeSort(aluno, 39, 4);
      mergeSort(aluno, 39, 3);
      mergeSort(aluno, 39, 2);
      mergeSort(aluno, 39, 1);
      break;

    case 4:
      //4. Ordenar por disciplina e média final (decrescente)
      mergeSort(aluno, 39, 7);
      mergeSort(aluno, 39, 5);
      break;
    
    case 5:
      //5. Ordenar por período, semestre, turma, disciplina e nome
      mergeSort(aluno, 39, 4);
      mergeSort(aluno, 39, 5);
      mergeSort(aluno, 39, 2);
      mergeSort(aluno, 39, 1);
      mergeSort(aluno, 39, 3);
      break;
  }
  
    for (int i = 0; i < 39; i++){
    printf("%s,", aluno[i].semestre);
    printf("%c,", aluno[i].turma);
    printf("%c,", aluno[i].periodo);
    printf("%s,", aluno[i].nome);
    printf("%s,", aluno[i].disciplina);
    printf("%s\n", aluno[i].media_final);
  }
  
  fclose(arquivo);


  printf("%lo\n", sizeof(struct aluno));
  
  printf("%lo\n", sizeof(aluno));
  printf("%lo", sizeof(int));
}



