#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#define TAM 40
#define TAM_SMALL 20

// Struct aluno é criada com 6 atributos, conforme descrito.
struct aluno
{
    int semestre;
    char turma;
    char periodo;
    char nome[TAM];
    char disciplina[TAM_SMALL];
    float media_final;
};


// Função contaLinhas: percorre cada linha do arquivo até encontrar um \n, após isso 
// tam é incrementado em 1 e o processo se repete até o fim do arquivo
int contaLinhas(FILE *arquivo) {
    int tam = 0;
    char caractere;
    while ((caractere = fgetc(arquivo)) != EOF) {
        if (caractere == '\n') {
            tam++;
        }
    }
    rewind(arquivo); // Volta ao início do arquivo após a contagem.
  
    return tam;
}

// Função Merge que faz a junção dos subarrays ordenados, recebe 6 parâm.

void merge(struct aluno aluno[], struct aluno esquerda[], int esquerda_tam, struct aluno direita[], int direita_tam, int opcao) {
    int i = 0, j = 0, k = 0;

    while (i < esquerda_tam && j < direita_tam) {
        switch (opcao) {

        case 1:
            if (esquerda[i].semestre <= direita[j].semestre) {
                aluno[k++] = esquerda[i++];
            }
            else {
                aluno[k++] = direita[j++];
            }
            break;
        case 2:
            if (esquerda[i].turma <= direita[j].turma) {
                aluno[k++] = esquerda[i++];
            }
            else {
                aluno[k++] = direita[j++];
            }
            break;

        case 3:
            if (esquerda[i].periodo <= direita[j].periodo) {
                aluno[k++] = esquerda[i++];
            }
            else {
                aluno[k++] = direita[j++];
            }
            break;
        case 4:
            if (strcmp(esquerda[i].nome, direita[j].nome) <= 0) {
                aluno[k++] = esquerda[i++];
            }
            else {
                aluno[k++] = direita[j++];
            }
            break;

        case 5: // Compara as strigs disciplida para saber se a primeira é <= que a segunda
            if (strcmp(esquerda[i].disciplina, direita[j].disciplina) <= 0) {
                aluno[k++] = esquerda[i++];
            }
            else {
                aluno[k++] = direita[j++];
            }
            break;

        case 6: // Comparação entre médias para saber se a primeira é <= que a segunda
            if (esquerda[i].media_final <= direita[j].media_final) {
                aluno[k++] = esquerda[i++];
            }
            else {
                aluno[k++] = direita[j++];
            }
            break;

        case 7:
            // Se a opção 7 for selecionada no param. opcao do merge, compara as medias finais (decrescente)
            if (esquerda[i].media_final > direita[j].media_final) {
                aluno[k++] = esquerda[i++];
            }
            else {
                aluno[k++] = direita[j++];
            }
            break;
        }
    }

    while (i < esquerda_tam) {
        aluno[k++] = esquerda[i++];
    }

    while (j < direita_tam) {
        aluno[k++] = direita[j++];
    }
}

void mergeSort(struct aluno *aluno, int size, int opcao) {
    if (size > 1) {
        int meio = size / 2;

        // Alocação dinâmica de memória para 'esquerda' e 'direita'
        struct aluno *esquerda = malloc(meio * sizeof(struct aluno));
        struct aluno *direita = malloc((size - meio) * sizeof(struct aluno));

        for (int i = 0; i < meio; i++) {
            esquerda[i] = aluno[i];
        }

        for (int i = meio; i < size; i++) {
            direita[i - meio] = aluno[i];
        }

        // Chamada recursiva para ordenar as duas metades
        mergeSort(esquerda, meio, opcao);
        mergeSort(direita, size - meio, opcao);

        // Mesclar as duas metades ordenadas
        merge(aluno, esquerda, meio, direita, size - meio, opcao);

        // Liberar a memória alocada
        free(esquerda);
        free(direita);
    }
}

int main(void) {
    FILE *arquivo;
    arquivo = fopen("Arquivo-projeto-teste.csv", "r");

    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

  
    int size_struct_aluno = contaLinhas(arquivo);
    printf("A quantidade de linhas é %d\n\n", size_struct_aluno);

    struct aluno *alunos = malloc(size_struct_aluno * sizeof(struct aluno));
    char linha[TAM * 2]; // Aumentei o tamanho da linha para acomodar todos os campos.

    for (int i = 0; i < size_struct_aluno; i++) {
      
        if (fgets(linha, sizeof(linha), arquivo) != NULL) {
          
            if (sscanf(linha, "%d,%c,%c,%40[^,],%20[^,],%f", &alunos[i].semestre, &alunos[i].turma, &alunos[i].periodo, alunos[i].nome, alunos[i].disciplina, &alunos[i].media_final) == 6) {
                // Sucesso na leitura da linha.
            } else {
                printf("Erro ao ler a linha do arquivo.\n");
            }
        } else {
            printf("Erro ao ler a linha do arquivo.\n");
        }
    }

    fclose(arquivo);

    int opcao;

    do {
        printf("1. Ordenar por nome\n"
               "2. Ordenar por semestre\n"
               "3. Ordenar por semestre, turma, período, disciplina e nome\n"
               "4. Ordenar por disciplina e média final (decrescente)\n"
               "5. Ordenar por período, semestre, turma, disciplina e nome\n\n"
               "Digite uma opção: ");

        scanf("%d", &opcao);
    } while (opcao != 1 && opcao != 2 && opcao != 3 && opcao != 4 && opcao != 5);

    switch (opcao) {

    case 1:
        //1. Ordenar por nome
        mergeSort(alunos, size_struct_aluno, 4);
        break;

    case 2:
        //2. Ordenar por semestre
        mergeSort(alunos, size_struct_aluno, 1);
        break;

    case 3:
        //3. Ordenar por semestre, turma, período, disciplina e nome\n

        mergeSort(alunos, size_struct_aluno, 5);
        mergeSort(alunos, size_struct_aluno, 4);
        mergeSort(alunos, size_struct_aluno, 3);
        mergeSort(alunos, size_struct_aluno, 2);
        mergeSort(alunos, size_struct_aluno, 1);
        break;

    case 4:
        //4. Ordenar por disciplina e média final (decrescente)
        mergeSort(alunos, size_struct_aluno, 7);
        mergeSort(alunos, size_struct_aluno, 5);
        break;

    case 5:
        //5. Ordenar por período, semestre, turma, disciplina e nome
        mergeSort(alunos, size_struct_aluno, 4);
        mergeSort(alunos, size_struct_aluno, 5);
        mergeSort(alunos, size_struct_aluno, 2);
        mergeSort(alunos, size_struct_aluno, 1);
        mergeSort(alunos, size_struct_aluno, 3);
        break;
    }

    arquivo = fopen("saida.csv", "w"); // Abrindo arquivo para escrita (write)

    if (arquivo == NULL) {
      printf("Erro ao abrir o arquivo.\n");
      return 1; // Encerra o programa com erro
  }
  
    for (int i = 0; i < size_struct_aluno; i++) {
        fprintf(arquivo, "%d,", alunos[i].semestre);
        fprintf(arquivo, "%c,", alunos[i].turma);
        fprintf(arquivo, "%c,", alunos[i].periodo);
        fprintf(arquivo, "%s,", alunos[i].nome);
        fprintf(arquivo, "%s,", alunos[i].disciplina);
        fprintf(arquivo, "%.2f\n", alunos[i].media_final);
    }
    
    fclose(arquivo); // Fechar o arquivo
    free(alunos); // Liberar a memória alocada para a estrutura de alunos.
    return 0;
}

